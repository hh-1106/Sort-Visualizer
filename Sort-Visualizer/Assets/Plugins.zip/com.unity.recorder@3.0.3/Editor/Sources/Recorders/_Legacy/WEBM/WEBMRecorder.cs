using System;
using UnityEngine;

namespace UnityEditor.Recorder.FrameCapturer
{
    class WEBMRecorder : GenericRecorder<WEBMRecorderSettings>
    {
        protected internal override void RecordFrame(RecordingSession session)
        {
        }
    }
}
