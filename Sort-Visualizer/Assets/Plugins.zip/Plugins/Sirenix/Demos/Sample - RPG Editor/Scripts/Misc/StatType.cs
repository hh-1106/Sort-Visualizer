#if UNITY_EDITOR
namespace Sirenix.OdinInspector.Demos.RPGEditor
{
    public enum StatType
    {
        Shooting,
        Melee,
        Social,
        Animals,
        Medicine,
        Cooking,
        Mining,
        Crafting
    }
}
#endif
