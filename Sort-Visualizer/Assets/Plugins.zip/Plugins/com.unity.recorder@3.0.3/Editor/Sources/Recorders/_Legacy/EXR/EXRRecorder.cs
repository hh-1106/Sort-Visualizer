using System;

namespace UnityEditor.Recorder.FrameCapturer
{
    class EXRRecorder : GenericRecorder<EXRRecorderSettings>
    {
        protected internal override void RecordFrame(RecordingSession session)
        {
        }
    }
}
