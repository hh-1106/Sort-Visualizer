using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Unity.Recorder.Tests")]
