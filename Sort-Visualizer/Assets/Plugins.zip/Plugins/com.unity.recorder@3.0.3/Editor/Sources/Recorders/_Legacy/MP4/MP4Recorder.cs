using System;
using UnityEngine;

namespace UnityEditor.Recorder.FrameCapturer
{
    class MP4Recorder : GenericRecorder<MP4RecorderSettings>
    {
        protected internal override void RecordFrame(RecordingSession session)
        {
        }
    }
}
